# CSC 7740 Final Project - Deliverable Package

**Identifying Coordinated Amazon Review Groups with Distributed Text and Graph Analysis**

Souhardya Saha Dip (ssahad1@lsu.edu), Riyadil Zannat (rzanna2@lsu.edu),
Asif Faisal Chowdhury (achowd6@lsu.edu)

The final report is submitted separately as a PDF, as instructed, and is not
included here.

## Main pipeline

| File | Purpose |
|---|---|
| `AmazonReviewCoordinationDF.py` | The complete PySpark Structured API pipeline: ingest, metadata join, adaptive time bucketing, co-occurrence self-join, GraphFrames connected components (with a label-propagation fallback), MinHash LSH text similarity, and seven-signal scoring. 151 distributed operations. |
| `run_local.sh` | Single local run over the full dataset. |
| `run_all_categories.sh` | One category at a time, for memory-constrained machines. |
| `requirements.txt` | Python dependencies. |
| `Dockerfile`, `.devcontainer/` | Reproducible development environment. |

Every tunable is an environment variable with a default, so the same file runs
locally and on a cluster unmodified: `REVIEWS_PATH`, `METADATA_PATH`,
`OUTPUT_ROOT`, `SPARK_MASTER`, `DRIVER_MEMORY`, `SHUFFLE_PARTITIONS`,
`CHECKPOINT_DIR`, `USE_GRAPHFRAMES`, `GRAPHFRAMES_PACKAGE`, `MINHASH_SEED`,
`MAX_REVIEWS_PER_COMPONENT`, `WRITE_ENRICHED`.

## Cluster deployment

| File | Purpose |
|---|---|
| `emr/run_emr.sh` | EMR step entry point. Resolves the cluster's real `fs.defaultFS` and pins the staging, event-log, warehouse and checkpoint URIs to fully-qualified `hdfs://host:port`. |
| `emr/bootstrap.sh` | EMR bootstrap action (NumPy, setuptools, GraphFrames). |
| `EMR_RUNBOOK.md` | Step-by-step cluster procedure. |

## Experiments and analysis

| File | Purpose |
|---|---|
| `analysis/sensitivity.py` | Time-window x co-occurrence-threshold parameter sweep. |
| `analysis/injection.py` | Synthetic coordination-ring injection and recall measurement. |
| `analysis/count_spark_operations.py` | AST-based count of Spark call sites (Appendix 2). |
| `analysis/create_sample_dataset.py` | Builds the sample dataset in this package. |
| `analysis/feasibility.py`, `pairest.py`, `lockstep.py`, `nearDup.py` | Exploratory sizing and threshold-selection scripts. |
| `analysis/DISTRIBUTED_OPERATIONS.md` | Per-call-site audit backing the Appendix 2 count of 201. |

## Sample dataset

`sample_data/` contains 5,037 reviews and metadata for 4,564 products
(4.8 MB compressed), not the full 24.4-million-review corpus. It deliberately
includes all 37 reviews of a verified three-account coordinated component, so a
smoke test exercises the repeated-pair and graph logic rather than returning
empty results.

Run the whole pipeline on it in under a minute:

    REVIEWS_PATH='sample_data/reviews_sample.jsonl.gz' \
    METADATA_PATH='sample_data/metadata_sample.jsonl.gz' \
    OUTPUT_ROOT=output/sample \
    SPARK_MASTER='local[2]' DRIVER_MEMORY=3g SHUFFLE_PARTITIONS=8 \
    USE_GRAPHFRAMES=0 WRITE_ENRICHED=0 \
    python3 AmazonReviewCoordinationDF.py

Expected: 5,037 reviews, 5,002 candidate groups, 3 repeated pairs,
1 component of 3 accounts, coordination score 0.554.

Fetch the full dataset with `analysis/download_data.sh`.

## Execution evidence

| Path | Contents |
|---|---|
| `evidence/emr_steps/runA-one-worker/` | AWS EMR step logs for the one-worker full-corpus run (7,368.6 s). |
| `evidence/emr_steps/runB-two-workers/` | The same for the two-worker run (6,030.4 s). |
| `evidence/full-run.log` | Local full-corpus baseline run. |
| `evidence/sensitivity-v2.log` | Parameter sweep output. |
| `evidence/injection-v2.log` | Injection test output. |

The `stdout` files contain the per-stage timings and the
`PIPELINE COMPLETED SUCCESSFULLY` summaries quoted in the report; the
`controller` files record each step's exit status.
